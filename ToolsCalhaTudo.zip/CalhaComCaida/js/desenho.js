const alturaInicial = document.getElementById("alturaInicial");
const alturaFinal = document.getElementById("alturaFinal");
const comprimentoTotal = document.getElementById("comprimentoTotal");
const tamanhoCorte = document.getElementById("tamanhoCorte");
const resultado = document.getElementById("resultado");

let altura = 9999;

alturaInicial.addEventListener("input", function () {
  getAlturas();
});

alturaFinal.addEventListener("input", function () {
  getAlturas();
});

comprimentoTotal.addEventListener("input", function () {
  getAlturas();
});

tamanhoCorte.addEventListener("input", function () {
  getAlturas();
});

function getAlturas() {
  altura = 9999;
  if (
    alturaInicial.value == "" ||
    alturaFinal.value == "" ||
    comprimentoTotal.value == "" ||
    tamanhoCorte.value == ""
  ) {
    return;
  }
  
  resultado.innerHTML = "";
  var altura_inicial = parseFloat(alturaInicial.value.replace(",", "."));
  var altura_final = parseFloat(alturaFinal.value.replace(",", "."));
  var comprimento_total = parseFloat(comprimentoTotal.value.replace(",", ".")) * 100;
  var tamanho_corte = parseFloat(tamanhoCorte.value.replace(",", ".")) * 100;

  var pecaAtual = 0;
  while (altura > altura_final) {
    pecaAtual++;
    var inclinacao = (altura_final - altura_inicial) / (comprimento_total - 1);
    var altura = altura_inicial + inclinacao * (tamanho_corte - 1);

    if (altura < altura_final) {
      altura = altura_final;
    }
    
    var p = document.createElement("p");
    p.innerHTML = `Peça ${pecaAtual}: &nbsp ${altura_inicial.toFixed(3)} cm x ${altura.toFixed(3)} cm`;
    resultado.appendChild(p);

    altura_inicial = altura;
    comprimento_total = comprimento_total - tamanho_corte;
  }
}
